(function($) {
	"use strict";

    $('ul#wc-item-meta li:nth-child(2)').addClass('second-li');
    $('.single_add_to_cart_button').addClass('common-add-to-cart');
	var finded = $('.product-detail-btn').next('.price').children('.woocommerce-Price-amount').addClass('product-detail-price');
	var current_url = document.location.href;
	var type ="credito-directo";
   	var oldURL = window.location.protocol +"//" + window.location.host + window.location.pathname;
    var newUrl = oldURL +"?type=" + type;
	if(current_url == newUrl){
        $("#tarjeta_id").removeAttr('checked');
        $("#directo_id").attr('checked', 'checked');
    	var price = $('.pcredito-price').val();
    	var month = $('.cuotas-month').val();
    	var installment = $('.installment').val();
    	var currency_symbol = $('.currency-symbol').val();
    	var product_price = $('.product-price').val();
    	var product_id = $('.product-id').val();
    	$('.directo_radio').addClass('activebtn');
    	window.history.pushState({ path: newUrl },'', newUrl);
        $('.common-add-to-cart').removeClass('single_add_to_cart_ajax_button');
        $('.common-add-to-cart').removeClass('single_add_to_cart_button');
        $('.common-add-to-cart').addClass('custom_add_to_cart');
    	//$("span.product-detail-price").replaceWith("<span class='woocommerce-Price-amount amount product-detail-price'><bdi><span class='woocommerce-Price-currencySymbol'>"+currency_symbol+"</span>"+installment+"</bdi></span><div class='installment-month'>"+month+" cuotas de:</div>");
		$(".wcp_custom_price").show();
		$("p.price").hide();
	}else{
         $("#directo_id").removeAttr('checked');
        $("#tarjeta_id").attr('checked', 'checked');
        $('.tarjeta_radio').addClass('activebtn');
        $('.directo_radio').removeClass('activebtn');
        $('.common-add-to-cart').removeClass('single_add_to_cart_ajax_button');
        $('.common-add-to-cart').removeClass('single_add_to_cart_button');
        $('.common-add-to-cart').addClass('custom_add_to_cart');
		$(".wcp_custom_price").hide();
		$("p.price").show();
    }
    $(document).on("click",".radio-btn-common",function(){
        // alert($("input[name='tarjeta']:checked").val());
    	// $('.installment-month').remove();
    	var button_type = $("input[name='tarjeta']:checked").val();
    	var price = $('.pcredito-price').val();
    	var month = $('.cuotas-month').val();
    	var installment = $('.installment').val();
    	var currency_symbol = $('.currency-symbol').val();
    	var product_price = $('.product-price').val();
    	var product_id = $('.product-id').val();

    	if(button_type == 'Crédito directo' && installment != ''){
    		window.history.pushState({ path: newUrl },'', newUrl);
    		$('.directo_radio').addClass('activebtn');
    		$('.tarjeta_radio').removeClass('activebtn');
            $('.common-add-to-cart').removeClass('single_add_to_cart_ajax_button');
            $('.common-add-to-cart').removeClass('single_add_to_cart_button');
            $('.common-add-to-cart').addClass('custom_add_to_cart');
    		//$("span.product-detail-price").replaceWith("<span class='woocommerce-Price-amount amount product-detail-price'><bdi><span class='woocommerce-Price-currencySymbol'>"+currency_symbol+"</span>"+installment+"</bdi></span><div class='installment-month'>"+month+" cuotas de:</div>");
			$(".wcp_custom_price").show();
			$("p.price").hide();
    	}else{
    		$('.directo_radio').removeClass('activebtn');
    		$('.tarjeta_radio').addClass('activebtn');
    		window.history.pushState({ path: oldURL },'', oldURL);
            $('.common-add-to-cart').removeClass('single_add_to_cart_ajax_button');
            $('.common-add-to-cart').removeClass('single_add_to_cart_button');
            $('.common-add-to-cart').addClass('custom_add_to_cart');
    		// $('.installment-month').remove();
    		$("span.product-detail-price").replaceWith("<span class='woocommerce-Price-amount amount product-detail-price'><bdi><span class='woocommerce-Price-currencySymbol'>"+currency_symbol+"</span>"+product_price+"</bdi></span>");
			$(".wcp_custom_price").hide();
			$("p.price").show();
    	}
    	//return false;
    }); 

    // add to js
    $('body').on('click', '.custom_add_to_cart', function(event) {
     	event.preventDefault();        
     	var button_type = $("input[name='tarjeta']:checked").val();
    	var price = $('.pcredito-price').val();
    	var month = $('.cuotas-month').val();
    	var installment = $('.installment').val();
    	var currency_symbol = $('.currency-symbol').val();
    	var product_price = $('.product-price').val();
    	var product_image = $('.product-image').val();
    	var product_name = $('#product_name_fetch').val();
    	var product_id = $('.product-id').val();
		var wcrw_warranty = $('.wcrw_warranty_info select[name="wcrw_warranty"]').val();
	    var senddata = '&button_type=' + button_type + '&price=' + price + '&month=' + month + '&installment=' + installment + '&product_image=' + product_image + '&product_name=' + product_name + '&product_price=' + product_price + '&product_id=' + product_id + '&action=update_product_meta&wcrw_warranty='+ wcrw_warranty;
		$(this).addClass('loading').html('').attr('disabled', 'disabled');
		$(".woocommerce-notices-wrapper").html('');
	    jQuery.ajax({
	        type: "POST",
			dataType: "json",
	        url: api_front_ajax.ajaxurl, 
	        data: senddata,
	        success: function(response) {
                var returnedata = response;
                var cart_url = returnedata.cart_url;
                var status = returnedata.status;
                var buttontype = returnedata.buttontype;
                // if(status == 'error' && buttontype == 'Tarjeta de Crédito')
                // {
                //     alert('Usted tiene un producto de CREDITO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.');
                // }
                // if(status == 'error' && buttontype == 'Crédito directo')
                // {
                //     alert('Usted tiene un producto de PAGO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.');
                // }
                if(status == 'success'){
                    // window.location.href = cart_url;
					$( document.body ).trigger( 'wc_fragment_refresh' );
					$(".header-cart").trigger('click');
					$('.custom_add_to_cart').removeClass('loading').html('Añadir al carrito').removeAttr('disabled');
                }else{
					//window.location.reload();
					$('.custom_add_to_cart').removeClass('loading').html('Añadir al carrito').removeAttr('disabled');
					$(".woocommerce-notices-wrapper").html('<ul class="woocommerce-error carttypeerror" role="alert"><li>'+returnedata.msg+'</li></ul>');
				}
	        }
	   	});
    	return false;
    });
})(jQuery);