<div class="wrap">
    <h1 class="wp-heading-inline">WCP Products 
        <button class="page-title-action" id="insert_wcp_products">UPDATE</button>
        <button class="page-title-action" id="update_wcp_products_stock_price">UPDATE (Stock/Price)</button>
        <button class="page-title-action" id="update_wcp_products_transient">Clear API Transient</button>
        <!-- <button class="page-title-action" id="update_wcp_products_slug">Update Slug</button> -->
		<div class="image_progress"></div>
    </h1>

    <div class="process" style="display: none;">
        <label for="import_progress">Importing progress: 0 Imported</label>
        <progress id="import_progress" value="0" max="100"></progress>
    </div>

    <?php
        if(isset($_POST['update_cron_setting'])){
            extract($_POST);
            update_option('cartimaxApiMode', $cartimaxApiMode);
            update_option('cronopt', $cronopt);
            update_option('apitoken', $apitoken);
            update_option('nomofproducts', round($nomofproducts));
        }
    ?>

    <form name="updateCRONsetting" method="post" autocomplete="off">
        <table class="form-table" role="presentation">
            <tbody>
                <tr>
                    <th scope="row"><label for="cartimaxApiMode">API Mode</label></th>
                    <td>
                        <select name="cartimaxApiMode" id="cartimaxApiMode" class="regular-text">
                            <option <?=(get_option('cartimaxApiMode') == 'Live') ? 'selected' : '' ;?> >Live</option>
                            <option <?=(get_option('cartimaxApiMode') == 'Staging' || get_option('cartimaxApiMode') == '') ? 'selected' : '' ;?> >Staging</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cronopt">Update Product By Cron</label></th>
                    <td>
                        <select name="cronopt" id="cronopt" class="regular-text" aria-describedby="cron-description">
                            <option <?=(get_option('cronopt') == 'Yes') ? 'selected' : '' ;?> >Yes</option>
                            <option <?=(get_option('cronopt') == 'No' || get_option('cronopt') == '') ? 'selected' : '' ;?> >No</option>
                        </select>
                        <p class="description" id="cron-description">The Cron will be trigger once a day.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="cronopt">Update API Token</label></th>
                    <td>
                        <textarea id="apitoken" name="apitoken" class="regular-text"><?=get_option('apitoken')?></textarea>
                        <p class="description" id="apitoken">Update API token from here for live mode.</p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><label for="nomofproducts">No. Of Products Update</label></th>
                    <td>
                        <input type="number" id="nomofproducts" name="nomofproducts" class="regular-text" value="<?=get_option('nomofproducts')?>" />
                        <p class="description" id="nomofproducts">Update x number of products at a time.</p>
                    </td>
                </tr>
            </tbody>
        </table>
        <p class="submit"><input type="submit" name="update_cron_setting" id="submit" class="button button-primary" value="Save Changes"></p>
    </form>
</div>

<style>
    .process {
        color: red;
        font-weight: bold;
        text-decoration: underline;
    }
	.image_progress code {
		background-color: #068719;
		color: #fff;
	}
    #update_wcp_products_transient,
    #update_wcp_products_transient:focus {
        background: #bf0909;
        border: #bf0909;
        color: #fff;
        font-weight: bold;
        box-shadow: none;
        outline: none;
    }

</style>
<script>
    jQuery(document).ready(function ($){
		const images_update_info = setInterval(function() {
			$.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'get_wcp_product_images_update_info'
                },
				success: function (response) {
					if(response.notUpdated == 0){
					   	clearInterval(images_update_info);
						$(".image_progress").html('');
					}else{
						$(".image_progress").html('<code>Images pending: '+response.notUpdated+' Images updated: '+response.Updated+'</code>');
					}
				}
			});
		}, 10000);
		
        $("#insert_wcp_products").click(function(){
            $(".process").show();
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'import_wcp_products',
                    type: 'insert',
                    paged: 1
                },
                success: function (response) {
                    if(response.Message){
                        $(".process").html(response.Message);
                    }else{
                        if(response.imp == 'next' && response.total_ins < response.total_products){
                            $(".process").html('<label for="import_progress">Importing progress: '+response.total_ins+' out of '+response.total_products+'</label><progress id="import_progress" value="'+response.total_ins+'" max="'+response.total_products+'"></progress>');
                            insert_wcp_products(response.paged);
                        }else{
                            $(".process").html(response.total_products+' out of '+response.total_products+' Imported.');
                        }
                    }
                }
            });
        });

        $("#update_wcp_products_stock_price").click(function(){
            $(".process").show();
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'wcp_products_stock_price_update',
                    type: 'update',
                    paged: 1
                },
                success: function (response) {
                    if(response.Message){
                        $(".process").html(response.Message);
                    }else{
                        if(response.imp == 'next' && response.total_ins < response.total_products){
                            $(".process").html('<label for="import_progress">Updating progress: '+response.total_ins+' out of '+response.total_products+'</label><progress id="import_progress" value="'+response.total_ins+'" max="'+response.total_products+'"></progress>');
                            update_wcp_products(response.paged);
                        }else{
                            $(".process").html(response.total_products+' out of '+response.total_products+' Updated.');
                        }
                    }
                }
            });
        });

        function insert_wcp_products(paged){
            $(".process").show();
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'import_wcp_products',
                    type: 'insert',
                    paged: paged
                },
                success: function (response) {
                    if(response.Message){
                        $(".process").html(response.Message);
                    }else{
                        if(response.imp == 'next' && response.total_ins < response.total_products){
                            $(".process").html('<label for="import_progress">Importing progress: '+response.total_ins+' out of '+response.total_products+'</label><progress id="import_progress" value="'+response.total_ins+'" max="'+response.total_products+'"></progress>');
                            insert_wcp_products(response.paged);
                        }else{
                            $(".process").html(response.total_products+' out of '+response.total_products+' Imported.');
                        }
                    }
                }
            });
        }

        function update_wcp_products(paged){
            $(".process").show();
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'wcp_products_stock_price_update',
                    type: 'update',
                    paged: paged
                },
                success: function (response) {
                    if(response.Message){
                        $(".process").html(response.Message);
                    }else{
                        if(response.imp == 'next' && response.total_ins < response.total_products){
                            $(".process").html('<label for="import_progress">Updating progress: '+response.total_ins+' out of '+response.total_products+'</label><progress id="import_progress" value="'+response.total_ins+'" max="'+response.total_products+'"></progress>');
                            update_wcp_products(response.paged);
                        }else{
                            $(".process").html(response.total_products+' out of '+response.total_products+' Updated.');
                        }
                    }
                }
            });
        }

        $("#update_wcp_products_transient").click(function(){
            $(this).addClass('dashicons-before dashicons-update');
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'update_wcp_products_transient',
                    type: 'update'
                },
                success: function (response) {
                    $("#update_wcp_products_transient").removeClass('dashicons-before dashicons-update');
                }
            });
        });

        $("#update_wcp_products_slug").click(function(){
            $(this).addClass('dashicons-before dashicons-update');
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'update_wcp_products_slug',
                    paged: 1
                },
                success: function (response) {
                    update_wcp_products_slug(response.paged);
                }
            });
        });

        function update_wcp_products_slug(paged){
            $.ajax({
                url: '<?=admin_url('admin-ajax.php')?>',
                type: 'POST',
                dataType: 'json',
                data: {
                    action: 'update_wcp_products_slug',
                    paged: paged
                },
                success: function (response) {
                    if(response.update){
                        update_wcp_products_slug(response.paged);
                    }
                }
            });
        }

    });
    
</script>

<?php
// echo '<pre>';
// print_r(get_post_meta(30132));
// print_r(get_api_products());
// print_r(get_transient( 'api_products' ));

// $args = array(
//     'posts_per_page'  => 5,
//     'post_type'       => 'product',
//     'meta_key' => '_price',
//     'orderby' => 'meta_value_num',
//     'order' => 'DESC'
// );

// $get_pro = new WP_Query($args);

// while ($get_pro->have_posts()) {
//     $get_pro->the_post();
//     echo get_the_ID().' '.get_the_permalink().' '.get_post_meta(get_the_ID(), '_regular_price', true).'<br>';
// }