<?php
/**
 * @package Woo Computron Product Import
 * @version 1.0
 */
/*
Plugin Name: Woo Computron Product Import
Plugin URI: https://www.helpfulinsightsolution.com/custom-plugin-development
Description: Plugin to insert/update computron.com.ec products into woocommerce
Author: Helpful Insight Pvt. Ltd.
Version: 1.0
Author URI: https://helpfulinsightsolution.com
*/

// Don't load directly.
if ( ! function_exists( 'is_admin' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

/**
 * Register a custom menu page.
 */
function wcp_products_menu(){
    add_menu_page( 
        'WCP Products',
        'WCP Products',
        'manage_options',
        'wcp_products',
        'wcp_products',
        '',
        6
    );
}
add_action( 'admin_menu', 'wcp_products_menu' );

add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), 'add_action_links' );
function add_action_links ( $actions ) {
   $mylinks = array(
      '<a href="' . admin_url( 'admin.php?page=wcp_products' ) . '">Settings</a>',
      '<a href="https://helpfulinsightsolution.com" style="color: #1da867; font-weight: bold;" target="_blank">Helpful Insight Pvt. Ltd.</a>',
   );
   $actions = array_merge( $actions, $mylinks );
   return $actions;
}

function wcp_products(){
    require_once(dirname( __FILE__ ) . '/wcp_products.php');
}

/* Front Enqueue */
function wcp_template_enqueue_front_script() {
    wp_enqueue_style('wcp_product_front', plugin_dir_url(__FILE__) . 'assets/product-front.css?ver='.time());
    wp_register_script('frontend_js', plugin_dir_url(__FILE__) . 'assets/frontend.js', array('jquery'));
    wp_localize_script('frontend_js', 'api_front_ajax', array('ajaxurl' => admin_url('admin-ajax.php')));
    wp_enqueue_script('frontend_js');
}
add_action('wp_enqueue_scripts', 'wcp_template_enqueue_front_script');

function get_wcp_products(){
    $apiMode = get_option('cartimaxApiMode');
    $apitoken = get_option('apitoken');
    if($apiMode == 'DEV'){
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://ws.cartimex.com:8060/api/Products/GetProductFulls',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_HTTPHEADER => array(
            'Content-Type: application/json',
            'Authorization: Bearer '.$apitoken
        ),
        ));
        
        $response = curl_exec($curl);
        // if (curl_errno($curl)) {
        //     echo $error_msg = curl_error($curl);
        // }
        
        curl_close($curl);
        // echo 'Hello';
        // echo $response; die();
        return json_decode($response);
    }else{
        $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => 'https://computron.com.ec/api/auth.php?token='.$apitoken,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => '',
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => 'GET',
        ));

        $response = curl_exec($curl);
        // if (curl_errno($curl)) {
        //     echo $error_msg = curl_error($curl);
        // }
        curl_close($curl);
        return json_decode($response);
    }
}

function update_wcp_products_transient(){
    global $wpdb;
    $wcp_products = get_wcp_products();
    $api_products = array();
    if($wcp_products && !empty($wcp_products)){
        foreach($wcp_products as $wcp_product){
            $api_products[] = $wcp_product->Code;
        }
    }
    // print_r($wcp_products);
    if($wcp_products){
        set_transient( 'api_products', $api_products, DAY_IN_SECONDS );
        set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
        set_transient( 'wcp_update_products', $wcp_products, DAY_IN_SECONDS );
    }else{
        delete_transient( 'api_products' );
        delete_transient( 'wcp_products' );
        delete_transient( 'wcp_update_products' );
    }
    
    wp_send_json(array('msg' => 'Updated'));
    wp_die();
}
add_action('wp_ajax_update_wcp_products_transient', 'update_wcp_products_transient');

function import_wcp_products(){
    global $wpdb;
    global $woocommerce;
    extract($_POST);
    $wcp_products = array();
    $getdata = 'api';

    if($paged == 1){
        $getdata = 'api';
        $wcp_products = get_wcp_products();
        set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );

        if (!wp_next_scheduled('wcp_task_hook')) {
            wp_schedule_event( time(), 'minutely', 'wcp_task_hook' );
        }

    }else{
        $getdata = 'transient';
        $wcp_products = get_transient( 'wcp_products' );
        if(!$wcp_products && empty($wcp_products)){
            $wcp_products = get_wcp_products();
            set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
            $getdata = 'api';
        }
    }

    if(!$wcp_products && empty($wcp_products)){
        $response = array('status' => 'auth', 'Message' => 'Failed to load API data. Try with staging mode.');
        wp_send_json($response);
        wp_die();
    }

    if($wcp_products->Message){
        $response = array('status' => 'auth', 'Message' => $wcp_products->Message);
        wp_send_json($response);
        wp_die();
    }

    $nomofproducts = (get_option('nomofproducts')) ? get_option('nomofproducts') : 100;
    // print_r($wcp_products);die();
    $total_products = count($wcp_products);
    $total_page = ceil($total_products / $nomofproducts);
    $divideProducts = array_chunk($wcp_products, $nomofproducts);
    $page = $paged - 1;
    $inserted = 0;
    $skipped = array();
    $response = array();
    $i = 0;
    foreach ($divideProducts[$page] as $wcp_product) {
        $p_up_id = check_if_product_already_exists($wcp_product->Code);
        if($p_up_id){
            $wcp_product->product_id = $p_up_id;
        }
        $product_id = insert_wcp_products( $wcp_product );
        if($product_id){
            $inserted++;
        }else{
            $skipped[] = $wcp_product->ID;
        }
        $i++;
    }

    $imp = 'next';
    if($paged == $total_page){
        $imp = 'finish';
        update_manual_product_stock();
    }

    if(($paged * $nomofproducts) == $total_products){
        $imp = 'finish';
    }

    $response = array('inserted' => $inserted, 'skipped' => $skipped, 'imp' => 'next', 'paged' => ($paged + 1), 'total_products' => $total_products, 'total_ins' => ($paged * $nomofproducts), 'getdata' => $getdata);
    wp_send_json($response);
    wp_die();
}
add_action("wp_ajax_import_wcp_products","import_wcp_products");

function insert_wcp_products( $args ){
    global $woocommerce;
    global $wpdb;
    // error_reporting(E_ALL);
    // ini_set('display_errors',1);
    // print_r(get_post_meta(3917, 'Garantias', true));die();

    // echo $args->Garantias;
    $gtrDetails = explode(';', $args->Garantias);
    $gtrArr = array();
    $grte = array();
    $_wcrw_override_default_warranty = 'no';
    if($gtrDetails){
        foreach($gtrDetails as $gtrDetail){
            $getGtr = explode(':', $gtrDetail);
            $numMonthFirst = str_replace("GARANTIA TODO RIESGO ","",$getGtr[0]);
            $numMonthSecond = str_replace(" MESES","",$numMonthFirst);

            $gtrArr[] = array(
                'price' => $getGtr[1],
                'length' => $numMonthSecond,
                'duration' => 'months'
            );
        }

        $grte = array(
            'label' => 'AGREGAR UN PLAN DE PROTECCIÓN',
            'type' => 'addon_warranty',
            'length' => '',
            'length_value' => '',
            'length_duration' => '',
            'hide_warranty' => 'no',
            'addon_settings' => $gtrArr
        );

        $_wcrw_override_default_warranty = 'yes';
    }

    $product_args = array(
        'post_type' => 'product',
        'post_title' => $args->Name,
        'post_content' => $args->Description,
        'post_status' => 'publish',
        'meta_input' => array(
            'APIID' => $args->ID,
            'ProductoID' => $args->ProductoID,
            'Imagenes' => $args->Imagenes,
            'Pcredito' => $args->Pcredito,
            'Cuotas' => $args->Cuotas,
            'Descuento' => $args->Descuento,
            'Ppromo' => $args->Ppromo,
            'Garantias' => $args->Garantias,
            '_sku' => isset( $args->Code ) ? $args->Code : '',
            '_regular_price' => $args->Price,
            '_sale_price' => ($args->Ppromo) ? $args->Ppromo : '',
            '_price' => ($args->Ppromo) ? $args->Ppromo : $args->Price,
            // '_tax_status' => isset($args->HaveTaxes) && $args->HaveTaxes ? 'taxable' : 'none',
            '_manage_stock' => isset( $args->Stock ) && $args->Stock ? 'yes' : 'no',
            // '_sold_individually' => isset( $args->VenderSolo ) && $args->VenderSolo ? 'yes' : 'no',
            '_sold_individually' => 'no',
            '_weight' => isset( $args->Weight ) ? $args->Weight : '',
            '_length' => isset( $args->Long ) ? $args->Long : '',
            '_width' => isset(  $args->Width ) ?  $args->Width  : '',
            '_height' => isset( $args->High ) ? $args->High : '',
            '_stock' => isset( $args->Stock ) && $args->Stock ? $args->Stock : 0,
            '_stock_status' => isset( $args->Stock ) && $args->Stock ? 'instock' : 'outofstock',
            'images_updated' => 'No',
            '_wcrw_product_warranty' => $grte,
            '_wcrw_override_default_warranty' => $_wcrw_override_default_warranty
        )
    );
    if($args->product_id){
        $galleryImgs = get_post_meta($args->product_id, '_product_image_gallery', true);
        $thumbnailImgs = get_post_meta($args->product_id, '_thumbnail_id', true);
        $deleteImgs = explode(",", $galleryImgs);
        $deleteImgs[] = $thumbnailImgs;
        if($deleteImgs){
            foreach($deleteImgs as $deleteImg){
                wp_delete_attachment( $deleteImg, true );
            }
        }
        $product_args['ID'] = $args->product_id;
    }

    $product_id = wp_insert_post($product_args);
    
    $parent_term = term_exists( $args->Category, 'product_cat' );
    $parent_term_id = $parent_term['term_id'];

    $catsid = '';
    $subcatsid = '';

    if($parent_term_id){
        $subterm = term_exists( $args->SubCategory, 'product_cat', $parent_term_id );
        if($subterm['term_id']){
            $catsid = $parent_term_id;
            $subcatsid = $subterm['term_id'];
        }else{
            $subcategory = wp_insert_term(
                $args->SubCategory,
                'product_cat',
                array(
                    'parent' => $parent_term_id
                )
            );
            $catsid = $parent_term_id;
            $subcatsid = $subcategory['term_id'];
        }
    }else{
        $MainCategory = wp_insert_term(
            $args->Category,
            'product_cat'
        );
        $subcategory = wp_insert_term(
            $args->SubCategory,
            'product_cat',
            array(
                'parent' => $MainCategory['term_id']
            )
        );
        $catsid = $MainCategory['term_id'];
        $subcatsid = $subcategory['term_id'];
    }

    $getproduct = wc_get_product($product_id);
    $getproduct->set_category_ids( array($catsid, $subcatsid ) );
    $getproduct->save();

    // wp_set_object_terms( $product_id, $catsid, 'product_cat' );
    // wp_set_object_terms( $product_id, $subcatsid, 'product_cat', true );
    // wp_set_object_terms( $product_id, $args->SubCategory, 'product_cat' );
    wp_set_object_terms( $product_id, $args->Mark, 'product_brand' );
    wp_set_object_terms( $product_id, $args->Mark, 'product_tag' );

    return $product_id;

}

function url_exists($url) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_NOBODY, true);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    return ($code == 200); // "status OK"
}

function wcp_cron_schedules($schedules){
    if(!isset($schedules["minutely"])){
        $schedules["minutely"] = array(
            'interval' => 60,
            'display' => __('Once every 1 minutes'));
    }
    if(!isset($schedules["daily"])){
        $schedules["daily"] = array(
            'interval' => 86400,
            'display' => __('Once Daily'));
    }
    return $schedules;
}
add_filter('cron_schedules','wcp_cron_schedules');

if (!wp_next_scheduled('wcp_cron_update_products')) {
    if(get_option('cronopt') == 'Yes'){
	    wp_schedule_event( time(), 'daily', 'wcp_cron_update_products' );
    }
}

if(get_option('cronopt') == 'No' && wp_next_scheduled('wcp_cron_update_products')){
    wp_clear_scheduled_hook( 'wcp_cron_update_products' );
}
add_action( 'wcp_cron_update_products', 'wcp_cron_update_products_672e06c5', 10, 0 );
add_action( 'wcp_task_hook', 'cron_wcp_task_hook_7bf9df38', 10, 0 );

function cron_wcp_task_hook_7bf9df38() {
    global $wpdb;
    global $woocommerce;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => 5,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key'     => 'images_updated',
                'compare' => 'NOT EXISTS', // works!
                'value' => '' // This is ignored, but is necessary...
            ),
            array(
                'key'     => 'images_updated',
                'value'   => 'No',
                'compare' => '='
            )
        )
    );

    $get_products = new WP_Query($args);

    if($get_products->have_posts()){

        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        while($get_products->have_posts()){
            $get_products->the_post();
            $product_id = get_the_ID();

            $gallery_ids = array();
            $imgid = '';
            $Imagenes = get_post_meta($product_id, 'Imagenes', true);
            if(isset( $Imagenes ) && $Imagenes){
                foreach($Imagenes as $gallery_image){
                    if(url_exists($gallery_image)){
                        $imgid = media_sideload_image( $gallery_image, 0, null, 'id' );
                        if(!is_wp_error( $imgid )){
                            $gallery_ids[] = $imgid;
                        }
                    }
                }

                if($gallery_ids){
                    update_post_meta($product_id, '_thumbnail_id', $gallery_ids[0]);
                    array_shift($gallery_ids);
                    update_post_meta($product_id, '_product_image_gallery', implode(',',$gallery_ids));
                }
            }
            update_post_meta($product_id, 'images_updated', 'Yes');
        }
        wp_reset_postdata();
        wp_reset_query();
    }else{
        wp_clear_scheduled_hook( 'wcp_task_hook' );
    }
}

function check_if_product_already_exists($sku){
    global $wpdb;
    global $woocommerce;
    $args = array(
        'post_type' => 'product',
        'meta_query' => array(
            array(
                'key'     => '_sku',
                'value'   => $sku,
                'compare' => '='
            )
        )
    );

    $get_products = new WP_Query($args);

    if($get_products->found_posts){
        while($get_products->have_posts()){
            $get_products->the_post();
            return get_the_ID();
        }
        wp_reset_postdata();
        wp_reset_query();
    }else{
        return false;
    }
}

function wcp_products_stock_price_update(){
    global $wpdb;
    global $woocommerce;
    extract($_POST);
    $wcp_products = array();
    $getdata = 'api';
    $nomofproducts = (get_option('nomofproducts')) ? get_option('nomofproducts') : 100;

    if($paged == 1){
        $getdata = 'api';
        $wcp_products = get_wcp_products();
        set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
    }else{
        $getdata = 'transient';
        $wcp_products = get_transient( 'wcp_products' );
        if(!$wcp_products && empty($wcp_products)){
            $wcp_products = get_wcp_products();
            set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
            $getdata = 'api';
        }
    }

    if($wcp_products->Message){
        $response = array('status' => 'auth', 'Message' => $wcp_products->Message);
        wp_send_json($response);
        wp_die();
    }

    $total_products = count($wcp_products);
    $total_page = ceil($total_products / $nomofproducts);
    $divideProducts = array_chunk($wcp_products, $nomofproducts);
    $page = $paged - 1;
    $updated = 0;
    $skipped = array();
    $response = array();
    $i = 0;

    foreach ($divideProducts[$page] as $wcp_product) {
        $p_id = check_if_product_already_exists($wcp_product->Code);
        if($p_id){
            update_post_meta($p_id, '_regular_price', $wcp_product->Price);
            update_post_meta($p_id, '_price', ($wcp_product->Ppromo) ? $wcp_product->Ppromo : $wcp_product->Price);
            update_post_meta($p_id, '_sale_price', ($wcp_product->Ppromo) ? $wcp_product->Ppromo : '');
            update_post_meta($p_id, '_stock', $wcp_product->Stock);
            $updated++;
        }else{
            $skipped[] = $wcp_product->ID;
        }
    }

    $imp = 'next';
    if($paged == $total_page){
        $imp = 'finish';
        update_manual_product_stock();
    }

    if(($paged * $nomofproducts) == $total_products){
        $imp = 'finish';
    }

    $response = array('updated' => $updated, 'skipped' => $skipped, 'imp' => 'next', 'paged' => ($paged + 1), 'total_products' => $total_products, 'total_ins' => ($paged * $nomofproducts), 'getdata' => $getdata);
    wp_send_json($response);
    wp_die();
}
add_action("wp_ajax_wcp_products_stock_price_update","wcp_products_stock_price_update");

function get_api_products(){
    global $wpdb;
    global $woocommerce;
    extract($_POST);
    $api_products = get_transient( 'api_products' );
    if($api_products && !empty($api_products)){
        return $api_products;
    }
    
    $getdata = 'transient';
    $wcp_products = get_transient( 'wcp_products' );
    if(!$wcp_products && empty($wcp_products)){
        $wcp_products = get_wcp_products();
        set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
        $getdata = 'api';
    }

    if($wcp_products->Message){
        return $wcp_products->Message;
    }

    if($wcp_products && !empty($wcp_products)){
        foreach($wcp_products as $wcp_product){
            $api_products[] = $wcp_product->Code;
        }
    }

    set_transient( 'api_products', $api_products, DAY_IN_SECONDS );

    return $api_products;
}

function update_manual_product_stock(){
    global $wpdb;
    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key'     => '_sku',
                'compare' => 'NOT EXISTS', // works!
                'value' => '' // This is ignored, but is necessary...
            ),
            array(
                'key'     => '_sku',
                'value'   => '',
                'compare' => '='
            ),
            array(
                'key'     => '_sku',
                'value'   => get_api_products(),
                'compare' => 'NOT IN'
            )
        )
    );

    $get_products = new WP_Query($args);
    // print_r($get_products->posts);die();
    if($get_products->have_posts()){
        while($get_products->have_posts()){
            $get_products->the_post();
            update_post_meta(get_the_ID(), '_stock', 0);
            update_post_meta(get_the_ID(), '_stock_status', 'outofstock');
        }
        wp_reset_postdata();
        wp_reset_query();
    }
}

function wcp_cron_update_products_672e06c5(){
    global $wpdb;
    global $woocommerce;
    $wcp_products = get_wcp_products();
    
    $inserted = 0;
    $skipped = array();
    $response = array();
    $i = 0;
    if($wcp_products){
        foreach ($wcp_products as $wcp_product) {
            $p_up_id = check_if_product_already_exists($wcp_product->Code);
            if($p_up_id){
                $wcp_product->product_id = $p_up_id;
            }
            $product_id = cron_insert_wcp_products( $wcp_product );
        }
    }
    wp_die();
}

function get_wcp_product_images_update_info(){
	global $wpdb;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'meta_query' => array(
            'relation' => 'OR',
            array(
                'key'     => 'images_updated',
                'compare' => 'NOT EXISTS', // works!
                'value' => '' // This is ignored, but is necessary...
            ),
            array(
                'key'     => 'images_updated',
                'value'   => 'No',
                'compare' => '='
            )
        )
    );

    $notUpdated = new WP_Query($args);
	
	$args = array(
        'post_type' => 'product',
        'posts_per_page' => -1,
        'meta_query' => array(
            array(
                'key'     => 'images_updated',
                'value'   => 'Yes',
                'compare' => '='
            )
        )
    );

    $Updated = new WP_Query($args);
	
	$response = array("notUpdated" => $notUpdated->found_posts, "Updated" => $Updated->found_posts);
	wp_send_json($response);
	wp_die();
}
add_action("wp_ajax_get_wcp_product_images_update_info","get_wcp_product_images_update_info");

function cron_insert_wcp_products( $args ){
    global $woocommerce;
    global $wpdb;

    $gtrDetails = explode(';', $args->Garantias);
    $gtrArr = array();
    $grte = array();
    $_wcrw_override_default_warranty = 'no';
    if($gtrDetails){
        foreach($gtrDetails as $gtrDetail){
            $getGtr = explode(':', $gtrDetail);
            $numMonthFirst = str_replace("GARANTIA TODO RIESGO ","",$getGtr[0]);
            $numMonthSecond = str_replace(" MESES","",$numMonthFirst);

            $gtrArr[] = array(
                'price' => $getGtr[1],
                'length' => $numMonthSecond,
                'duration' => 'months'
            );
        }

        $grte = array(
            'label' => 'AGREGAR UN PLAN DE PROTECCIÓN',
            'type' => 'addon_warranty',
            'length' => '',
            'length_value' => '',
            'length_duration' => '',
            'hide_warranty' => 'no',
            'addon_settings' => $gtrArr
        );

        $_wcrw_override_default_warranty = 'yes';
    }

    $product_args = array(
        'post_type' => 'product',
        'post_title' => $args->Name,
        'post_content' => $args->Description,
        'post_status' => 'publish',
        'meta_input' => array(
            'APIID' => $args->ID,
            'ProductoID' => $args->ProductoID,
            'Garantias' => $args->Garantias,
            'Pcredito' => $args->Pcredito,
            'Cuotas' => $args->Cuotas,
            '_sku' => isset( $args->Code ) ? $args->Code : '',
            '_regular_price' => $args->Price,
            '_sale_price' => ($args->Ppromo) ? $args->Ppromo : '',
            '_price' => ($args->Ppromo) ? $args->Ppromo : $args->Price,
            '_manage_stock' => isset( $args->Stock ) && $args->Stock ? 'yes' : 'no',
            '_weight' => isset( $args->Weight ) ? $args->Weight : '',
            '_length' => isset( $args->Long ) ? $args->Long : '',
            '_width' => isset(  $args->Width ) ?  $args->Width  : '',
            '_height' => isset( $args->High ) ? $args->High : '',
            '_stock' => isset( $args->Stock ) && $args->Stock ? $args->Stock : 0,
            '_stock_status' => isset( $args->Stock ) && $args->Stock ? 'instock' : 'outofstock',
            '_wcrw_product_warranty' => $grte,
            '_wcrw_override_default_warranty' => $_wcrw_override_default_warranty
        )
    );
    if($args->product_id){
        $product_args['ID'] = $args->product_id;
    }

    $product_id = wp_insert_post($product_args);
    
    $parent_term = term_exists( $args->Category, 'product_cat' );
    $parent_term_id = $parent_term['term_id'];

    $catsid = '';
    $subcatsid = '';

    if($parent_term_id){
        $subterm = term_exists( $args->SubCategory, 'product_cat', $parent_term_id );
        if($subterm['term_id']){
            $catsid = $parent_term_id;
            $subcatsid = $subterm['term_id'];
        }else{
            $subcategory = wp_insert_term(
                $args->SubCategory,
                'product_cat',
                array(
                    'parent' => $parent_term_id
                )
            );
            $catsid = $parent_term_id;
            $subcatsid = $subcategory['term_id'];
        }
    }else{
        $MainCategory = wp_insert_term(
            $args->Category,
            'product_cat'
        );
        $subcategory = wp_insert_term(
            $args->SubCategory,
            'product_cat',
            array(
                'parent' => $MainCategory['term_id']
            )
        );
        $catsid = $MainCategory['term_id'];
        $subcatsid = $subcategory['term_id'];
    }

    $getproduct = wc_get_product($product_id);
    $getproduct->set_category_ids( array($catsid, $subcatsid ) );
    $getproduct->save();

    wp_set_object_terms( $product_id, $args->Mark, 'product_brand' );
    wp_set_object_terms( $product_id, $args->Mark, 'product_tag' );

    return $product_id;

}

function wcp_script_box_before_post( $content ) {
    global $post;
    // retrieve the global notice for the current post
    if ( is_product() ) {
        $global_notice = get_post_meta( $post->ID, '_wcp_script_box', true );
        $content .= $global_notice;
    }
    return $content;
}
add_filter( 'the_content', 'wcp_script_box_before_post' );

function wcp_register_meta_boxes() {
    add_meta_box( 'update-current-product', 'Update Button', 'wcp_update_display_callback', 'product' );
}
add_action( 'add_meta_boxes', 'wcp_register_meta_boxes' );

function wcp_update_display_callback( $post ) {
    $searchedValue = get_post_meta($post->ID, 'APIID', true);
    if($searchedValue){ ?>
        <div class="apiSglUpdate"><span class="spinner"></span><button class="page-title-action" id="update_wcp_sgl_products_stock_price" type="button" data-id="<?=$post->ID?>">UPDATE (Stock/Price)</button></div>
            <style>
                #update_wcp_sgl_products_stock_price:hover {
                    background: #1185e3;
                }
                #update_wcp_sgl_products_stock_price {
                    background: #2271b1;
                    border: none;
                    border-radius: 5px;
                    color: #fff;
                    transition: all 0.5s ease;
                }
            </style>
            <script>jQuery(document).ready(function($){
                $("#update_wcp_sgl_products_stock_price").click(function(){
                    var pid = $(this).attr("data-id");
                    $(".apiSglUpdate .apiMsg").remove();
                    if(pid){
                        $(".apiSglUpdate .spinner").css("visibility", "visible");
                        $.ajax({
                            url: "<?=admin_url("admin-ajax.php")?>",
                            type: "POST",
                            dataType: "json",
                            data: {
                                action: "update_wcp_sgl_product_info",
                                pid: pid
                            },
                            success: function (response) {
                                $(".apiSglUpdate").append('<p class"apiMsg">'+response.msg+'</p>');
                                $(".apiSglUpdate .spinner").css("visibility", "hidden");
                                if(response.status == 'success'){
                                    window.location.reload();
                                }
                            }        
                        });
                    }
                });
            });</script> <?php
    }else{
        echo 'Manual Product';
    }
}

function update_wcp_sgl_product_info(){
    extract($_POST);
    $response = array();
    $searchedValue = get_post_meta($pid, 'APIID', true);
    if($searchedValue){
        $wcp_products = get_transient( 'wcp_products' );
        if(!$wcp_products && empty($wcp_products)){
            $wcp_products = get_wcp_products();
            set_transient( 'wcp_products', $wcp_products, DAY_IN_SECONDS );
            $getdata = 'api';
        }

        $neededObject = array_filter(
            $wcp_products,
            function ($e) use (&$searchedValue) {
                return $e->ID == $searchedValue;
            }
        );
        
        if($neededObject){
            foreach($neededObject as $wcp_product){
                $wcp_product->product_id = $pid;
                $pro_ID = insert_wcp_products( $wcp_product );
                if($pro_ID){
                    $response = array('status' => 'success', 'msg' => 'Product updated successfully.');
                    if (!wp_next_scheduled('wcp_task_hook')) {
                        wp_schedule_event( time(), 'minutely', 'wcp_task_hook' );
                    }
                }
            }
        }else{
            $response = array('status' => 'error', 'msg' => 'Product not found.');
        }
    }else{
        $response = array('status' => 'error', 'msg' => 'Product is not imported by API.');
    }

    wp_send_json($response);
    wp_die();
}
add_action('wp_ajax_update_wcp_sgl_product_info', 'update_wcp_sgl_product_info');


add_action( 'woocommerce_single_product_summary', 'custom_field_display_below_title', 10 );
function custom_field_display_below_title(){
    global $post;
    $post_id = $post->ID;
    $attributes = get_post_meta($post_id);
    $Pcredito = get_post_meta($post->ID, 'Pcredito', true);
    $Cuotas = get_post_meta($post->ID, 'Cuotas', true);
    $firstCuotas = $Cuotas[0];
    
    $CuotasString = $firstCuotas;
    $CuotasArray = explode(';', $CuotasString);
    $Cuotasmonth = $CuotasArray[0];

    $half_price_data = $firstCuotas;    
    $half_price = substr($half_price_data, strpos($half_price_data, ";") + 1);    
    $installment = ($half_price) ? number_format($half_price, 2) : '' ;
    $currency_symbol = get_woocommerce_currency_symbol(); 

    $product = wc_get_product( $post_id );

    $product_price = $product->get_price();
    
    $orignal_amount = number_format($product_price, 2);

    $orignal_price = str_replace('.',',',$orignal_amount);

    $productimage = get_the_post_thumbnail_url($productid);  

    $product_title = get_the_title();

    if($Pcredito != '')
    {
        echo '<input type="hidden" class="pcredito-price" value="'.$Pcredito.'">';
        echo '<input type="hidden" class="cuotas-month" value="'.$Cuotasmonth.'">
        <input type="hidden" class="installment" value="'.$installment.'">
        <input type="hidden" class="currency-symbol" value="'.$currency_symbol.'">
        <input type="hidden" class="product-price" value="'.$orignal_price.'">
        <input type="hidden" class="product-image" value="'.$productimage.'">
        <input type="hidden" class="product-name-get" id="product_name_fetch" value="'.$product_title.'">
        <input type="hidden" class="product-id" value="'.$post_id.'">';
        echo '<div class="product-detail-btn"><div class="radio-btn tarjeta_radio"><input type="radio" id="tarjeta_id" class="radio-btn-common" name="tarjeta" value="Tarjeta de Crédito" checked><label for="tarjeta_id">Tarjeta de Crédito</label></div>
       <div class="radio-btn directo_radio"> <input type="radio" id="directo_id" class="radio-btn-common" name="tarjeta" value="Crédito directo"><label for="directo_id">Crédito directo</label></div></div>';
       echo '<div class="wcp_custom_price" style="display: none;">
       <div class="price wcp_price"><span class="woocommerce-Price-amount amount"><bdi><span class="woocommerce-Price-currencySymbol">'.$currency_symbol.'</span>'.$installment.'</bdi></span><div class="installment-month">'.$Cuotasmonth.' cuotas de:</div></div>
       </div>';
    }
    
}

/* Update product meta */
function update_product_meta($atts) 
{

    $button_type = $_POST['button_type'];
    $price = $_POST['price'];
    $month = $_POST['month'];
    $installment = $_POST['installment'];
    $product_name = $_POST['product_name'];
    $product_image = $_POST['product_image'];
    $product_price = $_POST['product_price'];
    $wcrw_warranty = $_POST['wcrw_warranty'];
    
    global $wpdb, $woocommerce;
    $response = array();

    $product_id = $_POST['product_id'];

    $product_cart_id = WC()->cart->generate_cart_id( $product_id );

    $cart_item_key = WC()->cart->find_product_in_cart( $product_cart_id );

    if ( WC()->cart->get_cart_contents_count() == 0 ) 
    {
        if ($button_type == 'Crédito directo') 
        {
             $Details = array('button_type'=>$button_type,'custom_price'=>$price,'month'=>$month,'installment'=>$installment);

                $total_price = $price;

                $total_qnty = 1;

                $finaldetails = serialize($Details);

                $variation_id = null;

                if($woocommerce->cart->add_to_cart( $product_id, $total_qnty,$variation_id,null, array('wcrw_warranty_index' => $wcrw_warranty,'type' => 'other','custom_product_price' => $total_price, 'Details' => $finaldetails, 'cart_image' => $_POST['product_image'],'custom_product_name'=>$product_name) ) )
                {

                    $cart_url = $woocommerce->cart->get_cart_url();

                    $response = array('status' => 'success', 'cart_url' => $cart_url);

                }
                else
                {

                    $response = array('status' => 'defaulterror'); 

                }
        }
        else
        {
            $total_price = $product_price;

                $total_qnty = 1;

                $variation_id = null;

                if($woocommerce->cart->add_to_cart( $product_id, $total_qnty,$variation_id,null, array('wcrw_warranty_index' => $wcrw_warranty,'type' => 'default','custom_product_price' => $total_price, 'cart_image' => $_POST['product_image'],'custom_product_name'=>$product_name) ) )
                {

                    $cart_url = $woocommerce->cart->get_cart_url();

                    $response = array('status' => 'success', 'cart_url' => $cart_url);

                }
                else
                {

                    $response = array('status' => 'defaulterror');

                }
        }
    }
    else
    {
        foreach ( WC()->cart->get_cart() as $cart_item_key => $cart_item ) 
        {
            $product_type =  $cart_item['type'];
            if ($product_type == 'other' && $button_type == 'Crédito directo') 
            {

                $Details = array('button_type'=>$button_type,'custom_price'=>$price,'month'=>$month,'installment'=>$installment);

                $total_price = $price;

                $total_qnty = 1;

                $finaldetails = serialize($Details);

                $variation_id = null;

                if($woocommerce->cart->add_to_cart( $product_id, $total_qnty,$variation_id,null, array('wcrw_warranty_index' => $wcrw_warranty,'type' => 'other','custom_product_price' => $total_price, 'Details' => $finaldetails, 'cart_image' => $_POST['product_image'],'custom_product_name'=>$product_name) ) )
                {

                    $cart_url = $woocommerce->cart->get_cart_url();

                    $response = array('status' => 'success', 'cart_url' => $cart_url);

                }
                else
                {

                   $response = array('status' => 'defaulterror');

                }
            }
            else if($product_type == 'default' && $button_type == 'Tarjeta de Crédito')
            {
                $total_price = $product_price;

                $total_qnty = 1;

                $variation_id = null;

                if($woocommerce->cart->add_to_cart( $product_id, $total_qnty,$variation_id,null, array('wcrw_warranty_index' => $wcrw_warranty,'type' => 'default','custom_product_price' => $total_price, 'cart_image' => $_POST['product_image'],'custom_product_name'=>$product_name) ) )
                {

                    $cart_url = $woocommerce->cart->get_cart_url();

                    $response = array('status' => 'success', 'cart_url' => $cart_url);

                }
                else
                {

                    $response = array('status' => 'defaulterror');
                }
            }
            else
            {
                $response = array('status' => 'error', 'buttontype' => $button_type);
            }
        }
    }

    $return = array('status' => 'success', 'cart_url' => $woocommerce->cart->get_cart_url());
    if($response['status'] == 'error' && $response['buttontype'] == 'Tarjeta de Crédito'){
        //wc_add_notice('Usted tiene un producto de CREDITO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.','error');
        $return['status'] = 'error';
        $return['msg'] = 'Usted tiene un producto de CREDITO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.';
    }

    if($response['status'] == 'error' && $response['buttontype'] == 'Crédito directo'){
        //wc_add_notice('Usted tiene un producto de PAGO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.','error');
        $return['status'] = 'error';
        $return['msg'] = 'Usted tiene un producto de PAGO DIRECTO en su carrito de compras, si desea comprar este tipo de producto elimine el producto solicitado del carrito.';
    }

    wp_send_json($return);
    wp_die();
}
add_action('wp_ajax_update_product_meta', 'update_product_meta');
add_action('wp_ajax_nopriv_update_product_meta', 'update_product_meta');


function product_filter_woocommerce_cart_item_name($name, $cart_item, $cart_item_key)
{
    $currencysymbol = get_woocommerce_currency_symbol();
    $name_content = '';
    if(count($cart_item) > 0)
    {        
        if(isset($cart_item['type']) && $cart_item['type'] == 'other')
        {
            $Details = unserialize($cart_item['Details']);

            $name_content .= $cart_item['custom_product_name']."<br>"; 

            $name_content .= "Pago con crédito directo: </b>".$Details['month']." Meses<br>";

            $installment = $currencysymbol.$Details['installment'];

            $name_content .= '<span style="color: #fb641b;"></b>'.$installment.'</span>';

            $cart_item['data']->set_price($Details['custom_price']);
        }
        else
        {
            $name_content = $name;
        }


    }

    return $name_content;
}

add_filter( 'woocommerce_cart_item_name', 'product_filter_woocommerce_cart_item_name', 10, 3 );


add_action('woocommerce_add_order_item_meta', 'custom_meal_add_order_item_meta', 10, 2);

function custom_meal_add_order_item_meta($item_id, $values) 
{
    global $woocommerce;

    $currencysymbol = get_woocommerce_currency_symbol();

    if(isset($values['type']) && $values['type'] == 'other')
    {
        $Details = unserialize($values['Details']);

        $month = $Details['month'];
        $installment = $currencysymbol.$Details['installment'];
        $totalmonths =  $month.' Meses';
        woocommerce_add_order_item_meta($item_id, 'Details', $name_contents);
    
        woocommerce_add_order_item_meta($item_id, 'PAGO CON CRÉDITO DIRECTO', $totalmonths);

        woocommerce_add_order_item_meta($item_id, 'VALOR CUOTAS', $installment);

    } 


}

function change_price( $cart ) 
{

    if ( is_admin() && ! defined( 'DOING_AJAX' ) )
        return;

    foreach ( $cart->get_cart() as $key => $item ) {

        $product_type =  $item['type'];
        $custom_product_price = $item['custom_product_price'];
        if($product_type == 'other')
        {
            $item['data']->set_price($custom_product_price);
        }
    }
 }
 add_action( 'woocommerce_before_calculate_totals', 'change_price', 10, 1);

function woo_adon_plugin_template( $template, $template_name, $template_path ) 
{
     global $woocommerce;
     $_template = $template;
     if ( ! $template_path ) 
        $template_path = $woocommerce->template_url;
 
     $plugin_path  = untrailingslashit( plugin_dir_path( __FILE__ ) )  . '/woocommerce/';
 
    // Look within passed path within the theme - this is priority
    $template = locate_template(
    array(
      $template_path . $template_name,
      $template_name
    )
   );
 
   if( ! $template && file_exists( $plugin_path . $template_name ) )
    $template = $plugin_path . $template_name;
 
   if ( ! $template )
    $template = $_template;

   return $template;
}
add_filter( 'woocommerce_locate_template', 'woo_adon_plugin_template', 1, 3 );

add_filter( 'woocommerce_available_payment_gateways', 'disable_payment_gateways' );
function disable_payment_gateways( $available_gateways ) {
    if ( is_admin() ) return $available_gateways; // Only on frontend

    $gatewayNames = array_keys($available_gateways);

    global $woocommerce;
    $items = $woocommerce->cart->get_cart();
    if($items)
    {
        foreach ($items as $key1 => $values) 
        {
            $product_type = $values['type'];
            if($product_type == 'other')
            {
                foreach($gatewayNames as $gatewayName){
                    if($gatewayName != 'cod'){
                        unset( $available_gateways[$gatewayName] );
                    }
                }
            }
            else
            {
                unset( $available_gateways[ 'cod' ] );
            }
        }
    }

    return $available_gateways;
}

add_action("wp_ajax_update_wcp_products_slug","update_wcp_products_slug");
function update_wcp_products_slug(){
    extract($_POST);
    // error_reporting(E_ALL);
	// ini_set('display_errors',1);
    global $wpdb;
    $args = array(
        'post_type' => 'product',
        'post_status' => 'publish',
        'posts_per_page' => '100',
        'paged' => $paged
    );

    $get_products = new WP_Query($args);
    $i = 0;
    if($get_products->have_posts()){
        while($get_products->have_posts()){
            $get_products->the_post();

            /*$update = wp_update_post(array(
                "post_name" => '',
                "ID" => get_the_ID(),
            ));*/

            $tagis = get_the_terms( get_the_ID(), 'product_brand' );
            $ptags = array();
            foreach($tagis as $brand){
                array_push($ptags, $brand->name);
            }
            // print_r($ptags);
            $update = wp_set_object_terms( get_the_ID(), $ptags, 'product_tag', false );

            if($update){
                $i++;
            }
        }
    }

    wp_send_json(array('update' => $i,'paged' => ($paged + 1)));
    wp_die();
}

/**
 * Alter the query vars to include products which have the meta we are searching for.
 *
 * @param array $query_vars The current query vars.
 *
 * @return array
 */
function m_request_query( $query_vars ) {

	global $typenow;
	global $wpdb;
	global $pagenow;

	if ( 'product' === $typenow && isset( $_GET['s'] ) && 'edit.php' === $pagenow ) {
		$search_term  = esc_sql( sanitize_text_field( $_GET['s'] ) );
    // Split the search term by comma.
		$search_terms = explode( ',', $search_term );
    // If there are more terms make sure we also search for the whole thing, maybe it's not a list of terms.
		if ( count( $search_terms ) > 1 ) {
			$search_terms[] = $search_term;
		}
    // Cleanup the array manually to avoid issues with quote escaping.
		array_walk( $search_terms, 'trim' );
		array_walk( $search_terms, 'esc_sql' );
		$meta_key               = '_sku';
		$post_types             = array( 'product', 'product_variation' );
		$query                  = "SELECT DISTINCT posts.ID as product_id, posts.post_parent as parent_id FROM {$wpdb->posts} posts LEFT JOIN {$wpdb->postmeta} AS postmeta ON posts.ID = postmeta.post_id WHERE postmeta.meta_key = '{$meta_key}' AND postmeta.meta_value IN  ('" . implode( "','", $search_terms ) . "') AND posts.post_type IN ('" . implode( "','", $post_types ) . "') ORDER BY posts.post_parent ASC, posts.post_title ASC";
		$search_results         = $wpdb->get_results( $query );
		$product_ids            = wp_parse_id_list( array_merge( wp_list_pluck( $search_results, 'product_id' ), wp_list_pluck( $search_results, 'parent_id' ) ) );
		$query_vars['post__in'] = array_merge( $product_ids, $query_vars['post__in'] );
	}

	return $query_vars;
}

add_filter( 'request', 'm_request_query', 20 );

// echo '<pre>';
// print_r(get_post_meta(3281));
// echo '</pre>';

/**
 * Customize ordering by price
 */
add_filter('woocommerce_get_catalog_ordering_args', function ($args) {
    $orderby_value = isset($_GET['orderby']) ? wc_clean($_GET['orderby']) : apply_filters('woocommerce_default_catalog_orderby', get_option('woocommerce_default_catalog_orderby'));
    if ('price' == $orderby_value) {
        $args['orderby'] = 'meta_value';
        $args['order'] = 'ASC';
        $args['meta_key'] = '_price';
    }

    if ('price-desc' == $orderby_value) {
        $args['orderby'] = 'meta_value';
        $args['order'] = 'DESC';
        $args['meta_key'] = '_price';
    }
    // print_r($args);

    return $args;
});